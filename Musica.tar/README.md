# Musica
A simple SQL-based database used to catalog/archive music that avoids the bloat and nonsense inherent in discogs
